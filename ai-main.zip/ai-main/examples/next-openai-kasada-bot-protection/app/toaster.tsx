'use client';

export { Toaster as default } from 'sonner';
